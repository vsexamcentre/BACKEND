# Exam Centre Backend (Express + MongoDB)

## What this project provides
- User authentication (register/login) with bcrypt + JWT
- Test model (title, date, duration, totalMarks, questions)
- Create tests via JSON POST
- Upload tests via CSV (admin) — endpoint `/api/tests/upload-csv`
- List tests: GET `/api/tests`

## Quick start (local)
1. Copy `.env.example` to `.env` and fill `MONGO_URI` and `JWT_SECRET`.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start server:
   ```bash
   npm run dev
   # or: npm start
   ```
4. Server runs on `http://localhost:5000` by default.

## Deploying to Render
- Push this repo to GitHub.
- Create a Web Service on Render, connect the repo, set the build command `npm install` and start command `npm start`.
- Add environment variables on Render matching your `.env`.

## CSV format for `/api/tests/upload-csv` (single file upload, field name: file)
The CSV must include a header row. Example:

```
title,date,duration,totalMarks,question,optionA,optionB,optionC,optionD,correct
Daily Test - 1,2025-11-06,30,100,What is 2+2?,3,4,5,6,B
Daily Test - 1,2025-11-06,30,100,What is 10*2?,15,20,25,30,B
```

Questions belonging to the same `title` and `date` will be grouped into one Test automatically.
