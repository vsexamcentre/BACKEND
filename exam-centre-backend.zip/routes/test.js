const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const path = require('path');
const Test = require('../models/Test');
const auth = require('../middleware/authMiddleware');

// Simple JSON create (admin)
router.post('/', auth('admin'), async (req, res) => {
  try {
    const test = new Test(req.body);
    await test.save();
    res.json({ success: true, test });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all tests (sorted by date desc)
router.get('/', async (req, res) => {
  try {
    const tests = await Test.find().sort({ date: -1 });
    res.json(tests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single test
router.get('/:id', async (req, res) => {
  try {
    const test = await Test.findById(req.params.id);
    if (!test) return res.status(404).json({ error: 'Not found' });
    res.json(test);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Upload CSV to create tests (admin)
// Uses multer to accept uploads
const upload = multer({ dest: 'uploads/' });

router.post('/upload-csv', auth('admin'), upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    const filepath = path.join(__dirname, '..', req.file.path);
    const rows = [];
    fs.createReadStream(filepath)
      .pipe(csv({ skipLines: 0, strict: true }))
      .on('data', (data) => rows.push(data))
      .on('end', async () => {
        // Group rows by title+date
        const groups = {};
        for (const r of rows) {
          // Normalize keys (allow different header casing)
          const title = r.title || r.Title || r.test || r.Test || 'Untitled Test';
          const dateStr = r.date || r.Date || new Date().toISOString().slice(0,10);
          const key = `${title}___${dateStr}`;
          if (!groups[key]) {
            groups[key] = { title, date: new Date(dateStr), duration: Number(r.duration||r.Duration||30), totalMarks: Number(r.totalMarks||r.TotalMarks||0), questions: [] };
          }
          const qText = r.question || r.Question || r.questionText || r['Question Text'] || '';
          const optA = r.optionA || r.OptionA || r['Option A'] || r['A'] || '';
          const optB = r.optionB || r.OptionB || r['Option B'] || r['B'] || '';
          const optC = r.optionC || r.OptionC || r['Option C'] || r['C'] || '';
          const optD = r.optionD || r.OptionD || r['Option D'] || r['D'] || '';
          const correct = (r.correct || r.Correct || '').toString().trim();
          const options = [optA, optB, optC, optD].filter(x => x !== '');
          groups[key].questions.push({
            questionText: qText,
            options,
            correctAnswer: correct
          });
        }
        // Save each group as a Test
        const created = [];
        for (const k of Object.keys(groups)) {
          const g = groups[k];
          const test = new Test(g);
          await test.save();
          created.push(test);
        }
        // remove uploaded file
        fs.unlinkSync(filepath);
        res.json({ success: true, createdCount: created.length, created });
      });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
